// File: src/app/api/mobile/alert/route.ts
import { NextRequest } from 'next/server';
import prisma from '@/lib/prisma';
import { getMobileAuthUser } from '@/lib/mobile-auth';
import { mobileOk, mobileFail } from '@/lib/mobile-response';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function GET(req: NextRequest) {
  try {
    const authUser = getMobileAuthUser(req);

    // 1. Ambil Notifikasi Sistem (Termasuk Kuota Internet & Peringatan Dini)
    const notificationWhereClause = authUser 
      ? { OR: [{ userId: authUser.id }, { userId: null }] }
      : { userId: null };

    const rawNotifications = await prisma.notification.findMany({
      where: notificationWhereClause,
      orderBy: { createdAt: 'desc' },
      take: 20,
      include: { node: { select: { name: true, nodeCode: true } } },
    });

    // 2. Ambil Incident Audio/Ancaman Suara
    const rawAudioIncidents = await prisma.audioIncident.findMany({
      take: 20,
      orderBy: { createdAt: 'desc' },
      include: { node: { select: { name: true, nodeCode: true } } },
    });

    // 3. Ambil Anomali Partikulat/Asap Kebakaran
    const rawAnomalies = await prisma.sensorReading.findMany({
      where: {
        OR: [
          { pm25: { gte: 190.0 } },
          { statusTerpadu: { contains: 'Kebakaran' } },
          { statusTerpadu: { contains: 'Asap' } },
          { statusTerpadu: { contains: 'Ancaman' } }
        ]
      },
      take: 20,
      orderBy: { recordedAt: 'desc' },
      include: { node: { select: { name: true, nodeCode: true } } },
    });

    // MAPPING UNIFIED ALERT FOR FLUTTER
    const combinedAlerts = [
      ...rawNotifications.map((n) => ({
        id: `notif-${n.id}`,
        title: n.title,
        message: n.message,
        category: n.title.includes('KUOTA') ? 'KUOTA_INTERNET' : (n.type || 'INFO'),
        level: n.type === 'DANGER' ? 'HIGH' : (n.type === 'WARNING' ? 'MEDIUM' : 'LOW'),
        nodeCode: n.node?.nodeCode || 'NODE-001',
        nodeName: n.node?.name || 'Node Rimbarest',
        createdAt: n.createdAt,
      })),

      ...rawAudioIncidents.map((a) => ({
        id: `audio-${a.id}`,
        title: `🚨 ANCAMAN SUARA: ${a.label.toUpperCase()}`,
        message: `Model DS-CNN mengidentifikasi "${a.label}" dengan akurasi ${((a.predictionScore ?? 0.95) * 100).toFixed(0)}% pada ${a.node?.name || 'Node'}.`,
        category: 'ANCAMAN_AUDIO',
        level: 'HIGH',
        nodeCode: a.node?.nodeCode || 'NODE-001',
        nodeName: a.node?.name || 'Node Rimbarest',
        createdAt: a.createdAt,
        audioUrl: a.audioUrl,
      })),

      ...rawAnomalies.map((p) => {
        // 🔥 PENANGANAN TS18047: Mengonversi p.pm25 & p.temperature menjadi number aman
        const pm25Value = Number(p.pm25 ?? 0);
        const tempValue = Number(p.temperature ?? 0);

        return {
          id: `partikulat-${p.id}`,
          title: pm25Value >= 190 ? '🔥 BAHAYA KEBAKARAN HUTAN' : '⚠️ PERINGATAN KUALITAS UDARA',
          message: `Status: ${p.statusTerpadu || 'Waspada'}. Konsentrasi PM2.5 mencapai ${pm25Value} µg/m³ pada suhu ${tempValue}°C.`,
          category: 'KEBAKARAN_PARTIKULAT',
          level: pm25Value >= 190 ? 'HIGH' : 'MEDIUM',
          nodeCode: p.node?.nodeCode || 'NODE-001',
          nodeName: p.node?.name || 'Node Rimbarest',
          createdAt: p.recordedAt,
        };
      }),
    ];

    // URUTKAN BERDASARKAN WAKTU TERBARU
    combinedAlerts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return mobileOk({ alerts: combinedAlerts }, 'OK', 200);
  } catch (error: any) {
    return mobileFail(error.message, 500);
  }
}