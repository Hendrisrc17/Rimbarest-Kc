import { NextRequest } from 'next/server';
import { verifyToken } from './jwt';

/**
 * 🌟 BARU — Helper otentikasi khusus endpoint mobile.
 * Membaca header "Authorization: Bearer <token>" dan mengembalikan payload JWT
 * ({ id, username, role }) atau null jika tidak valid/kosong.
 * Tidak mengubah lib/jwt.ts maupun middlewares/auth.ts yang sudah ada.
 */
export function getMobileAuthUser(req: NextRequest): { id: string; username: string; role: string } | null {
  const authHeader = req.headers.get('authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;

  const token = authHeader.split(' ')[1];
  if (!token) return null;

  return verifyToken(token);
}
