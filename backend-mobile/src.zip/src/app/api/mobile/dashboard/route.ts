// File: src/app/api/mobile/dashboard/route.ts
import { NextRequest } from 'next/server';
import prisma from '@/lib/prisma';
import { getMobileAuthUser } from '@/lib/mobile-auth';
import { mobileOk, mobileFail } from '@/lib/mobile-response';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    // 🌟 BEBAS BLOKIR: Ambil user jika ada, tapi JANGAN gagalkan pengunjung (Bypass 401)
    const authUser = getMobileAuthUser(req);

    // 1. Tarik data sensor terkini dengan sangat cepat
    const allLatestReadings = await prisma.sensorReading.findMany({
      take: 5,
      orderBy: { recordedAt: 'desc' },
      include: { node: { select: { name: true, nodeCode: true, status: true } } },
    });

    const activeReading = allLatestReadings.length > 0 ? allLatestReadings[0] : null;

    if (activeReading && activeReading.node && activeReading.node.status !== 'ONLINE') {
      try {
        await prisma.deviceNode.update({
          where: { id: activeReading.nodeId },
          data: { status: 'ONLINE', lastSeen: new Date() }
        });
      } catch (e) {
        console.error('⚠️ Gagal update status node:', e);
      }
    }

    // 2. Query paralel agregasi sistem
    const notificationWhereClause = authUser 
      ? { status: 'UNREAD' as const, OR: [{ userId: authUser.id }, { userId: null }] }
      : { status: 'UNREAD' as const, userId: null }; 

    const [totalNodes, onlineNodes, offlineNodes, unreadNotifications, latestIncidents, rawWeeklyReadings] =
      await Promise.all([
        prisma.deviceNode.count(),
        prisma.deviceNode.count({ where: { status: 'ONLINE' } }),
        prisma.deviceNode.count({ where: { status: 'OFFLINE' } }),
        prisma.notification.count({ where: notificationWhereClause }),
        prisma.audioIncident.findMany({
          take: 3, 
          orderBy: { createdAt: 'desc' },
          // 🌟 PERBAIKAN ESENSIAL: Kolom audioUrl ditarik dari DB agar terkirim ke mobile
          select: {
            id: true,
            nodeId: true,
            sensorReadingId: true,
            audioUrl: true, 
            predictionScore: true,
            label: true,
            createdAt: true,
            node: { select: { name: true, nodeCode: true } }
          }
        }),
        prisma.sensorReading.findMany({
          take: 15, 
          orderBy: { recordedAt: 'desc' },
          select: { pm25: true, noiseLevel: true, recordedAt: true },
        }),
      ]);

    const weeklyReadings = rawWeeklyReadings.reverse();

    const currentReadings = activeReading ? {
      id: activeReading.id,
      nodeId: activeReading.nodeId,
      pm1: Number(activeReading.pm1 ?? 0),
      pm25: Number(activeReading.pm25 ?? 0),
      pm10: Number(activeReading.pm10 ?? 0),
      temperature: Number(activeReading.temperature ?? 0),
      suhu: Number(activeReading.temperature ?? 0),
      humidity: Number(activeReading.humidity ?? 0),
      kelembapan: Number(activeReading.humidity ?? 0),
      noiseLevel: Number(activeReading.noiseLevel ?? 0),
      statusTerpadu: activeReading.statusTerpadu || '✅ NORMAL BERSIH',
      recordedAt: activeReading.recordedAt,
      node: activeReading.node,
      pm25Status: 'NORMAL',
      pm10Status: 'NORMAL',
      pm25Trend: 'Stabil',
      pm10Trend: 'Stabil',
    } : null;

    const aiInsight = activeReading ? {
      message: activeReading.statusTerpadu || 'Sistem mendeteksi kondisi lingkungan dalam batas aman dan normal.',
      tags: (() => {
        const dynamicTags: string[] = [];
        try {
          const payload = typeof activeReading.rawPayload === 'string' 
            ? JSON.parse(activeReading.rawPayload) 
            : activeReading.rawPayload;
          if (payload) {
            if (payload.aiDetectedAudioLabel && payload.aiDetectedAudioLabel !== 'Silence') dynamicTags.push(payload.aiDetectedAudioLabel);
            if (payload.aiKategoriAsap && payload.aiKategoriAsap !== 'Udara Bersih') dynamicTags.push(payload.aiKategoriAsap);
          }
        } catch (e) {}
        if ((activeReading.statusTerpadu || '').toUpperCase().includes('ANOMALI')) dynamicTags.push('ANOMALI');
        if (dynamicTags.length === 0) dynamicTags.push('NORMAL');
        return dynamicTags;
      })()
    } : { message: 'Belum ada analisis pola lingkungan terbaru.', tags: ['STANDBY'] };

    return mobileOk({
      summary: { totalNodes, onlineNodes, offlineNodes, unreadNotifications },
      currentReadings,
      latestReadings: allLatestReadings,
      latestIncidents,
      aiInsight,
      weeklyChartData: weeklyReadings.map((r) => ({
        pm25: Number(r.pm25 ?? 0),
        noiseLevel: Number(r.noiseLevel ?? 0),
        time: r.recordedAt.toISOString(),
      })),
      ...(currentReadings ?? {}),
    }, 'OK', 200);
  } catch (error: any) {
    return mobileFail(error.message, 500);
  }
}