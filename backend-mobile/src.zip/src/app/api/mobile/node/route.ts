// Endpoint mobile: GET /api/mobile/node
// Daftar seluruh node beserta bacaan sensor terakhirnya (untuk peta/list di aplikasi Flutter).
import { NextRequest } from 'next/server';
import prisma from '@/lib/prisma';
import { getMobileAuthUser } from '@/lib/mobile-auth';
import { mobileOk, mobileFail } from '@/lib/mobile-response';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const authUser = getMobileAuthUser(req);
    if (!authUser) return mobileFail('Sesi tidak valid, silakan login kembali', 401);

    const nodes = await prisma.deviceNode.findMany({
      include: {
        sensorReadings: {
          orderBy: { recordedAt: 'desc' },
          take: 1,
        },
      },
      orderBy: { nodeCode: 'asc' },
    });

    return mobileOk(nodes, 'Daftar node berhasil diambil', 200);
  } catch (error: any) {
    console.error('❌ [MOBILE][node][GET] Error:', error);
    return mobileFail(error.message || 'Terjadi kesalahan pada server', 500);
  }
}
