// File: src/app/api/mobile/live-monitoring-frekuensi-audio/route.ts
import { NextRequest } from 'next/server';
import prisma from '@/lib/prisma';
import { getMobileAuthUser } from '@/lib/mobile-auth';
import { mobileOk, mobileFail } from '@/lib/mobile-response';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    // 1. Validasi Autentikasi Sesi Mobile
    const authUser = getMobileAuthUser(req);
    if (!authUser) {
      return mobileFail('Sesi tidak valid, silakan login kembali', 401);
    }

    const { searchParams } = new URL(req.url);
    const nodeCode = searchParams.get('nodeCode');
    const limit = Math.min(parseInt(searchParams.get('limit') || '20', 10) || 20, 200);

    // 🎯 KONDISI A: PENCARIAN SPESIFIK PER PERANGKAT NODE (Riwayat Grafik Detail)
    if (nodeCode) {
      const node = await prisma.deviceNode.findUnique({ 
        where: { nodeCode } 
      });
      
      if (!node) {
        return mobileFail('Node tidak ditemukan', 404);
      }

      const [readings, incidents] = await Promise.all([
        prisma.sensorReading.findMany({
          where: { nodeId: node.id },
          orderBy: { recordedAt: 'desc' },
          take: limit,
          select: { id: true, noiseLevel: true, statusTerpadu: true, recordedAt: true },
        }),
        prisma.audioIncident.findMany({
          where: { nodeId: node.id },
          orderBy: { createdAt: 'desc' },
          take: 10,
        }),
      ]);

      return mobileOk({ node, readings, incidents }, 'Riwayat audio node berhasil diambil', 200);
    }

    // 🎯 KONDISI B: MONITORING GLOBAL (Untuk Dashboard List Semua Alat di Hutan)
    // 🚀 OPTIMASI SAKTI: Menggunakan pemisahan query agar engine PostgreSQL tidak dipaksa melakukan join scan raksasa.
    const activeNodes = await prisma.deviceNode.findMany({
      orderBy: { nodeCode: 'asc' },
    });

    const [recentIncidents, allLatestReadings] = await Promise.all([
      prisma.audioIncident.findMany({
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: { node: { select: { name: true, nodeCode: true } } },
      }),
      // Ambil data sensor terbaru dari database secara global untuk menghemat siklus RAM laptop
      prisma.sensorReading.findMany({
        orderBy: { recordedAt: 'desc' },
        distinct: ['nodeId'], // Hanya ambil 1 data paling gres untuk tiap alat!
        select: { id: true, nodeId: true, noiseLevel: true, statusTerpadu: true, recordedAt: true }
      })
    ]);

    // 🛠️ MAPPING STRATEGI: Gabungkan data node dengan sensor terbarunya di level memori (Super Cepat!)
    const nodesWithLatestReading = activeNodes.map(node => {
      const latestReading = allLatestReadings.find(r => r.nodeId === node.id);
      return {
        ...node,
        // Struktur data disamakan dengan format awal agar Flutter tidak perlu diubah-ubah kodenya
        sensorReadings: latestReading ? [latestReading] : []
      };
    });

    return mobileOk(
      { nodes: nodesWithLatestReading, recentIncidents }, 
      'Data live monitoring audio berhasil diambil', 
      200
    );

  } catch (error: any) {
    console.error('❌ [MOBILE][live-monitoring-frekuensi-audio] Error:', error);
    return mobileFail(error.message || 'Terjadi kesalahan pada server', 500);
  }
}