// File: lib/screens/particulate/widgets/particulate_aqi_scale.dart
import 'package:flutter/material.dart';

class ParticulateAqiScale extends StatelessWidget {
  final String currentKategori;

  const ParticulateAqiScale({
    super.key,
    required this.currentKategori,
  });

  @override
  Widget build(BuildContext context) {
    final cleanKat = currentKategori.toLowerCase();

    // 🌟 Pemetaan Fleksibel Deteksi Status 4 Opsi Asap Lapangan
    final bool isBersih = cleanKat.contains('bersih') ||
        cleanKat.isEmpty ||
        cleanKat.contains('normal');
    final bool isDebu = cleanKat.contains('polusi') ||
        cleanKat.contains('debu') ||
        cleanKat.contains('lokal');
    final bool isTebal =
        cleanKat.contains('tebal') || cleanKat.contains('kecil-sedang');
    final bool isKritis = cleanKat.contains('besar') ||
        cleanKat.contains('pekat') ||
        cleanKat.contains('kritis');

    return Row(
      children: [
        _buildScaleSegment("Bersih", Colors.green, isBersih),
        _buildScaleSegment("Lokal/Debu", Colors.amber, isDebu),
        _buildScaleSegment("Tebal", Colors.orange, isTebal),
        _buildScaleSegment("Kritis", Colors.red, isKritis),
      ],
    );
  }

  Widget _buildScaleSegment(String title, Color color, bool isActive) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 2),
        height: 28,
        decoration: BoxDecoration(
          color: isActive ? color : color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(6),
          border:
              isActive ? Border.all(color: Colors.black87, width: 1.5) : null,
        ),
        alignment: Alignment.center,
        child: Text(
          title,
          style: TextStyle(
            fontSize: 10,
            fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
            color: isActive ? Colors.white : color.withOpacity(0.8),
          ),
        ),
      ),
    );
  }
}
