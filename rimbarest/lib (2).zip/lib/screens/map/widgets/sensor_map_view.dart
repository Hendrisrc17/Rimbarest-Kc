// File: lib/screens/map/widgets/sensor_map_view.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

import '../../../theme/app_theme.dart';
import '../data/map_node_data.dart';

class SensorMapView extends StatefulWidget {
  final List<MapNodeData> nodes;
  final int? selectedNode;
  final AnimationController pingCtrl;
  final ValueChanged<int> onNodeTap;

  const SensorMapView({
    super.key,
    required this.nodes,
    required this.selectedNode,
    required this.pingCtrl,
    required this.onNodeTap,
  });

  @override
  State<SensorMapView> createState() => _SensorMapViewState();
}

class _SensorMapViewState extends State<SensorMapView> {
  StreamSubscription<Position>? _positionStreamSubscription;
  final MapController _mapController = MapController();
  LatLng _center = const LatLng(-2.129486, 106.113042);
  bool _hasMovedCamera = false;

  @override
  void initState() {
    super.initState();
    _initLiveLocationTracking();
  }

  @override
  void dispose() {
    _positionStreamSubscription?.cancel();
    _mapController.dispose();
    super.dispose();
  }

  Future<void> _initLiveLocationTracking() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return;

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return;
    }
    if (permission == LocationPermission.deniedForever) return;

    // Stream GPS HP real-time: memicu pembaruan setiap ada pergerakan minimal 1 meter
    _positionStreamSubscription = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 1,
      ),
    ).listen((Position position) {
      if (mounted) {
        setState(() {
          _center = LatLng(position.latitude, position.longitude);

          // Tindih koordinat NODE-001 secara live menggunakan hardware GPS HP
          if (widget.nodes.isNotEmpty) {
            widget.nodes[0].latitude = position.latitude;
            widget.nodes[0].longitude = position.longitude;
          }

          // Otomatis arahkan kamera pusat peta ke posisi Anda saat pertama kali lock dapet sinyal
          if (!_hasMovedCamera) {
            _mapController.move(_center, 16.0);
            _hasMovedCamera = true;
          }
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppTheme.borderMedium),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: FlutterMap(
          mapController: _mapController,
          options: MapOptions(
            initialCenter: _center,
            initialZoom: 15.0,
            maxZoom: 18.0,
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.rimbarest.app',
            ),
            MarkerLayer(
              markers: widget.nodes.map((node) {
                return Marker(
                  point: LatLng(node.latitude, node.longitude),
                  width: 60,
                  height: 60,
                  child: GestureDetector(
                    onTap: () => widget.onNodeTap(node.id),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        AnimatedBuilder(
                          animation: widget.pingCtrl,
                          builder: (context, child) {
                            return Container(
                              width: 15 + (widget.pingCtrl.value * 35),
                              height: 15 + (widget.pingCtrl.value * 35),
                              decoration: BoxDecoration(
                                color: node.color.withValues(
                                    alpha: 1.0 - widget.pingCtrl.value),
                                shape: BoxShape.circle,
                              ),
                            );
                          },
                        ),
                        Icon(node.icon, color: node.color, size: 34),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
