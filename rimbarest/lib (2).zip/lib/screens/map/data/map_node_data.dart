// File: lib/screens/map/data/map_node_data.dart
import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';

enum MapNodeStatus {
  good,
  warning,
  critical, // Status Kritis (Kebakaran Besar)
  offline,
}

class MapNodeData {
  final int id;
  final String nodeCode;
  final String name;

  double latitude;
  double longitude;

  MapNodeStatus status;
  double pm;
  double db;

  // 🤖 Menampung teks prediksi cerdas dari AI Server secara real-time
  String customAiLabel;

  MapNodeData({
    required this.id,
    required this.nodeCode,
    required this.name,
    this.latitude = -2.129486,
    this.longitude = 106.113042,
    required this.status,
    required this.pm,
    required this.db,
    this.customAiLabel = 'MEMUAT DATA...',
  });

  // 🎨 WARNA DINAMIS BERDASARKAN HASIL PREDIKSI AI
  Color get color {
    switch (status) {
      case MapNodeStatus.critical:
        return Colors.red.shade900; // Merah Tua / Kebakaran Besar
      case MapNodeStatus.warning:
        return AppTheme.danger; // Merah / Waspada
      case MapNodeStatus.offline:
        return Colors.grey; // Abu-abu / Alat Mati
      case MapNodeStatus.good:
        return AppTheme.success; // Hijau / Aman
    }
  }

  // 📍 ICON DINAMIS
  IconData get icon {
    switch (status) {
      case MapNodeStatus.critical:
        return Icons.local_fire_department_rounded;
      case MapNodeStatus.warning:
        return Icons.warning_rounded;
      case MapNodeStatus.offline:
        return Icons.location_off_rounded;
      case MapNodeStatus.good:
        return Icons.location_on_rounded;
    }
  }

  // 📝 TEKS STATUS MURNI KELUARAN DARI AI SERVER LU
  String get statusLabel => customAiLabel;

  bool get isOnline => status != MapNodeStatus.offline;

  // 📡 PARSER UTAMA: Mengambil nilai riil sensor & teks AI terupdate
  void updateFromApi(Map<String, dynamic> json) {
    try {
      Map<String, dynamic> sourceData = json;

      // 1. Cek apakah data sensor dibungkus array 'sensorReadings' (Prisma Next.js)
      if (json['sensorReadings'] != null &&
          (json['sensorReadings'] as List).isNotEmpty) {
        final readingsList = json['sensorReadings'] as List;
        // Ambil data pertama karena Next.js lu sudah disetel take: 1 & orderBy desc
        sourceData = readingsList.first as Map<String, dynamic>;
      }

      // 2. Ekstrak Angka PM2.5 dan Noise Level (dB) murni dari hardware/DB
      pm = double.tryParse(sourceData['pm25']?.toString() ?? '0.0') ?? 0.0;
      db = double.tryParse(sourceData['noiseLevel']?.toString() ??
              sourceData['db']?.toString() ??
              '0.0') ??
          0.0;

      // 3. Ambil string status hasil klasifikasi model AI Python yang dikirim Next.js
      String statusAiRaw = json['status']?.toString() ??
          sourceData['status']?.toString() ??
          'AMAN';

      // Masukkan teks AI ke label utama
      customAiLabel = statusAiRaw.toUpperCase();

      // 4. Sinkronkan visual warna pin & radar sesuai dengan teks AI lu
      String statusLower = statusAiRaw.toLowerCase();
      if (statusLower.contains('kebakaran') ||
          statusLower.contains('besar') ||
          statusLower.contains('critical')) {
        status = MapNodeStatus.critical;
      } else if (statusLower.contains('waspada') ||
          statusLower.contains('warning') ||
          statusLower.contains('siaga')) {
        status = MapNodeStatus.warning;
      } else if (statusLower.contains('offline') ||
          statusLower.contains('mati')) {
        status = MapNodeStatus.offline;
      } else {
        status = MapNodeStatus.good;
      }

      debugPrint(
          '🔥 DATA SENSOR MASUK -> PM: $pm, dB: $db, AI Status: $customAiLabel');
    } catch (e) {
      debugPrint('🚨 Gagal urai JSON di map_node_data: $e');
    }
  }
}

// 🚀 INISIALISASI AWAL (NILAI DUMMY KAKU SUDAH DIHAPUS TOTAL)
List<MapNodeData> globalMapNodes = [
  MapNodeData(
    id: 0,
    nodeCode: 'NODE-001',
    name: 'NODE-001',
    status: MapNodeStatus.good,
    pm: 0.0, // Mulai dari 0, wajib diupdate oleh data asli sensor
    db: 0.0, // Mulai dari 0, wajib diupdate oleh data asli sensor
    customAiLabel: 'MENUNGGU AI...',
  ),
];
