import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:permission_handler/permission_handler.dart'; // 1. Import package-nya di sini
import 'theme/app_theme.dart';
import 'screens/splash_screen.dart';

void main() async {
  // 2. Tambahkan 'async' di sini karena pengecekan izin bersifat asynchronous
  WidgetsFlutterBinding.ensureInitialized();

  // 3. Panggil fungsi pengecekan izin sebelum aplikasi me-render UI
  await cekIzinAplikasi();

  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      systemNavigationBarColor: Colors.white,
      systemNavigationBarIconBrightness: Brightness.dark,
    ),
  );
  runApp(const RimbaRestApp());
}

// 4. Fungsi untuk meminta izin Mikrofon & Lokasi (untuk BLE/IoT) secara interaktif
Future<void> cekIzinAplikasi() async {
  // Meminta izin mikrofon (Audio Tracking) dan lokasi (IoT Sync) sekaligus
  Map<Permission, PermissionStatus> statuses = await [
    Permission.microphone,
    Permission.location,
  ].request();

  // Opsional: Kamu bisa melacak statusnya jika diperlukan untuk debugging
  if (statuses[Permission.microphone]!.isDenied) {
    debugPrint("User menolak izin Mikrofon.");
  }
  if (statuses[Permission.location]!.isDenied) {
    debugPrint("User menolak izin Lokasi.");
  }
}

class RimbaRestApp extends StatelessWidget {
  const RimbaRestApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RimbaRest',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme.copyWith(
        textTheme: GoogleFonts.outfitTextTheme(
          AppTheme.lightTheme.textTheme,
        ),
      ),
      home: const SplashScreen(),
    );
  }
}
