import 'dart:convert';
import 'package:http/http.dart' as http;

import '../auth/api_config.dart';
import '../auth/auth_service.dart';

class ParticulateService {
  static Future<Map<String, String>> _headers() async {
    final token = await AuthService.getToken();

    return {
      "Content-Type": "application/json",
      "Accept": "application/json",
      if (token != null && token.isNotEmpty) "Authorization": "Bearer $token",
    };
  }

  static dynamic _handle(http.Response response) {
    final data = jsonDecode(response.body);

    if (response.statusCode >= 200 && response.statusCode < 300) {
      return data;
    }

    throw Exception(data["message"] ?? "Request gagal");
  }

  /// Mengambil data log history untuk keperluan tabel/spreadsheet
  static Future<List<dynamic>> getHistory() async {
    // 🌟 DISINKRONKAN: Mengarah ke endpoint /iot/sensor
    final response = await http.get(
      Uri.parse("${ApiConfig.baseUrl}/iot/sensor?all=true"),
      headers: await _headers(),
    );

    final decoded = _handle(response);

    // Validasi struktur response API
    if (decoded is Map && decoded["data"] != null) {
      return decoded["data"] as List;
    } else if (decoded is List) {
      return decoded;
    }

    return [];
  }

  /// Mengambil data terbaru untuk Dashboard UI (Mendukung Peringatan IoT Mati)
  static Future<Map<String, dynamic>> getLatest() async {
    // 🌟 DISINKRONKAN: Mengarah ke endpoint /iot/sensor
    final readingsRes = await http.get(
      Uri.parse("${ApiConfig.baseUrl}/iot/sensor"),
      headers: await _headers(),
    );

    final predictionsRes = await http.get(
      Uri.parse("${ApiConfig.baseUrl}/particulate-predictions"),
      headers: await _headers(),
    );

    final notificationsRes = await http.get(
      Uri.parse("${ApiConfig.baseUrl}/notifications"),
      headers: await _headers(),
    );

    // Parsing data JSON root level dari masing-masing response
    final readings = _handle(readingsRes);
    final predictions = _handle(predictionsRes);
    final notifications = _handle(notificationsRes);

    final List readingList = readings["data"] ?? [];
    final List predictionList = predictions["data"] ?? [];
    final List notificationList = notifications["data"] ?? [];

    Map<String, dynamic>? latestReading;
    Map<String, dynamic>? latestDetection;
    Map<String, dynamic>? latestNotification;

    // 🌟 EKSTRAKSI DEVICE ALERT (STATUS MATI DARI BACKEND NEXT.JS)
    Map<String, dynamic> deviceAlert = {
      "alert": false,
      "message": "",
    };

    if (readings is Map && readings["deviceAlert"] != null) {
      deviceAlert = {
        "alert": readings["deviceAlert"]["alert"] ?? false,
        "message": readings["deviceAlert"]["message"] ?? "",
        "disconnected_nodes":
            readings["deviceAlert"]["disconnectedNodes"] ?? [],
      };
    }

    if (readingList.isNotEmpty) {
      final r = Map<String, dynamic>.from(readingList.first);

      latestReading = {
        "id": r["id"],
        "node_id": r["nodeId"],
        "node_name": r["node"]?["name"] ?? r["node"]?["nodeCode"] ?? "NODE-001",
        // 🌟 MENANGKAP STATUS ONLINE / OFFLINE LOGIKAL DARI PRISMA NODE
        "node_status": r["node"]?["status"] ?? "OFFLINE",
        "pm1": r["pm1"],
        "pm25": r["pm25"],
        "pm10": r["pm10"],
        "humidity": r["humidity"],
        "temperature": r["temperature"],
        "battery_level": r["batteryLevel"],
        "signal_strength": r["signalStrength"],
        "recorded_at": r["recordedAt"],
      };
    }

    if (predictionList.isNotEmpty) {
      final p = Map<String, dynamic>.from(predictionList.first);

      latestDetection = {
        "id": p["id"],
        "node_id": p["nodeId"],
        "prediction": p["prediction"],
        "label": p["label"],
        "confidence": p["anomalyScore"] ?? 0,
        "risk_level": p["riskLevel"]?.toString().toLowerCase() ?? "normal",
        "created_at": p["createdAt"],
      };
    }

    if (notificationList.isNotEmpty) {
      final n = Map<String, dynamic>.from(notificationList.first);

      latestNotification = {
        "id": n["id"],
        "title": n["title"],
        "message": n["message"],
        "priority": n["priority"],
        "status": n["status"],
        "created_at": n["createdAt"],
      };
    }

    return {
      "latest_reading": latestReading,
      "latest_detection": latestDetection,
      "latest_notification": latestNotification,
      "device_alert": deviceAlert,
    };
  }

  static Future<void> sendTestData({
    required double pm25,
    required double pm10,
    required double humidity,
    required double temp,
    double pm1 = 0.0,
  }) async {
    final nodeId = await _getOrCreateNode();

    // 🌟 DISINKRONKAN: Mengarah ke endpoint /iot/sensor
    final readingRes = await http.post(
      Uri.parse("${ApiConfig.baseUrl}/iot/sensor"),
      headers: await _headers(),
      body: jsonEncode({
        "nodeId": nodeId,
        "pm1": pm1,
        "pm25": pm25,
        "pm10": pm10,
        "humidity": humidity,
        "temperature": temp,
        "batteryLevel": 87.0,
        "signalStrength": 75.0,
        "cacheSource": false,
        "rawPayload": {
          "pm1": pm1,
          "pm25": pm25,
          "pm10": pm10,
          "humidity": humidity,
          "temperature": temp,
          "sentFrom": "Flutter Test Client"
        }
      }),
    );

    final readingData = _handle(readingRes);
    final sensorReadingId = readingData["data"]?["id"];

    final risk = _riskFromPm(pm25, pm10);

    await http.post(
      Uri.parse("${ApiConfig.baseUrl}/particulate-predictions"),
      headers: await _headers(),
      body: jsonEncode({
        "nodeId": nodeId,
        "sensorReadingId": sensorReadingId,
        "prediction":
            risk == "NORMAL" ? "Udara normal" : "Polusi/asap terdeteksi",
        "label": risk == "NORMAL" ? "NORMAL" : "ASAP",
        "anomalyScore": pm25,
        "threshold": 100,
        "riskLevel": risk,
        "rawResult": {
          "pm1": pm1,
          "pm25": pm25,
          "pm10": pm10,
          "humidity": humidity,
          "temperature": temp,
        },
      }),
    );
  }

  static Future<String> _getOrCreateNode() async {
    final res = await http.get(
      Uri.parse("${ApiConfig.baseUrl}/nodes"),
      headers: await _headers(),
    );

    final data = _handle(res);
    final List nodes = data["data"] ?? [];

    if (nodes.isNotEmpty) {
      return nodes.first["id"].toString();
    }

    final createRes = await http.post(
      Uri.parse("${ApiConfig.baseUrl}/nodes"),
      headers: await _headers(),
      body: jsonEncode({
        "nodeCode": "NODE-001",
        "name": "Node Partikulat 001",
        "locationName": "Hutan Rimbarest",
        "latitude": -2.1291,
        "longitude": 106.1138,
        "status": "ONLINE",
        "batteryLevel": 87.0,
        "signalStrength": 75.0,
        "description": "Node uji partikulat dari Flutter",
      }),
    );

    final created = _handle(createRes);
    return created["data"]["id"].toString();
  }

  static String _riskFromPm(double pm25, double pm10) {
    if (pm25 >= 200 || pm10 >= 400) return "KRITIS";
    if (pm25 >= 120 || pm10 >= 250) return "BAHAYA";
    if (pm25 >= 75 || pm10 >= 150) return "WASPADA";
    return "NORMAL";
  }
}
