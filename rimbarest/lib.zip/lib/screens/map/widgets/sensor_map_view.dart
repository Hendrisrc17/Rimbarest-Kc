import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';
import '../data/map_node_data.dart';
import 'map_bg_painter.dart';
import 'map_node_pin.dart';

class SensorMapView extends StatelessWidget {
  final List<MapNodeData> nodes;
  final int? selectedNode;
  final AnimationController pingCtrl;
  final ValueChanged<int> onNodeTap;

  const SensorMapView({
    super.key,
    required this.nodes,
    required this.selectedNode,
    required this.pingCtrl,
    required this.onNodeTap,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppTheme.borderMedium),
            boxShadow: [
              BoxShadow(
                color: AppTheme.primary.withValues(alpha: 0.06),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: CustomPaint(
              size: const Size(double.infinity, double.infinity),
              painter: MapBgPainter(),
            ),
          ),
        ),
        LayoutBuilder(
          builder: (_, constraints) {
            final mapWidth = constraints.maxWidth - 32;
            final mapHeight = constraints.maxHeight;

            return Stack(
              children: nodes.map((node) {
                final x = 16 + node.x * mapWidth;
                final y = node.y * mapHeight;

                return Positioned(
                  left: x - 16,
                  top: y - 16,
                  child: GestureDetector(
                    onTap: () => onNodeTap(node.id),
                    child: MapNodePin(
                      node: node,
                      selected: selectedNode == node.id,
                      pingCtrl: pingCtrl,
                    ),
                  ),
                );
              }).toList(),
            );
          },
        ),
      ],
    );
  }
}
