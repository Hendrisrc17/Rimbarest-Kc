import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';

enum MapNodeStatus {
  good,
  warning,
  offline,
}

class MapNodeData {
  final int id;
  final String name;
  final double x;
  final double y;
  final MapNodeStatus status;
  final double pm;
  final double db;

  const MapNodeData({
    required this.id,
    required this.name,
    required this.x,
    required this.y,
    required this.status,
    required this.pm,
    required this.db,
  });

  Color get color {
    switch (status) {
      case MapNodeStatus.warning:
        return AppTheme.danger;
      case MapNodeStatus.offline:
        return AppTheme.textLight;
      case MapNodeStatus.good:
        return AppTheme.success;
    }
  }

  IconData get icon {
    switch (status) {
      case MapNodeStatus.warning:
        return Icons.warning_rounded;
      case MapNodeStatus.offline:
        return Icons.signal_wifi_off;
      case MapNodeStatus.good:
        return Icons.sensors;
    }
  }

  String get statusLabel {
    switch (status) {
      case MapNodeStatus.warning:
        return 'WASPADA';
      case MapNodeStatus.offline:
        return 'OFFLINE';
      case MapNodeStatus.good:
        return 'AMAN';
    }
  }

  bool get isOnline => status != MapNodeStatus.offline;
}

const mapNodes = [
  MapNodeData(
    id: 0,
    name: 'A1 - Hutan Lindung',
    x: 0.62,
    y: 0.28,
    status: MapNodeStatus.good,
    pm: 22.1,
    db: 58.0,
  ),
  MapNodeData(
    id: 1,
    name: 'A2 - Hutan Lindung',
    x: 0.55,
    y: 0.72,
    status: MapNodeStatus.good,
    pm: 31.4,
    db: 65.0,
  ),
  MapNodeData(
    id: 2,
    name: 'B1 - Hutan Lindung',
    x: 0.38,
    y: 0.18,
    status: MapNodeStatus.warning,
    pm: 67.2,
    db: 72.0,
  ),
  MapNodeData(
    id: 3,
    name: 'B2 - Hutan Lindung',
    x: 0.18,
    y: 0.45,
    status: MapNodeStatus.good,
    pm: 18.9,
    db: 54.0,
  ),
  MapNodeData(
    id: 4,
    name: 'C1 - Hutan Lindung',
    x: 0.70,
    y: 0.50,
    status: MapNodeStatus.good,
    pm: 29.5,
    db: 60.0,
  ),
  MapNodeData(
    id: 5,
    name: 'C2 - Hutan Lindung',
    x: 0.52,
    y: 0.40,
    status: MapNodeStatus.good,
    pm: 25.1,
    db: 63.0,
  ),
  MapNodeData(
    id: 6,
    name: 'D1 - Hutan Lindung',
    x: 0.28,
    y: 0.62,
    status: MapNodeStatus.good,
    pm: 20.3,
    db: 51.0,
  ),
  MapNodeData(
    id: 7,
    name: 'D2 - Hutan Lindung',
    x: 0.72,
    y: 0.80,
    status: MapNodeStatus.offline,
    pm: 0.0,
    db: 0.0,
  ),
];
