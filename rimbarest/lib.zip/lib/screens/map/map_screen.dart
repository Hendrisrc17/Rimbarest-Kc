import 'package:flutter/material.dart';

import '../../theme/app_theme.dart';
import 'data/map_node_data.dart';
import 'widgets/map_header.dart';
import 'widgets/map_legend.dart';
import 'widgets/map_node_detail.dart';
import 'widgets/sensor_map_view.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController pingCtrl;
  int? selectedNode;

  @override
  void initState() {
    super.initState();

    pingCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat();
  }

  @override
  void dispose() {
    pingCtrl.dispose();
    super.dispose();
  }

  void toggleNode(int id) {
    setState(() {
      selectedNode = selectedNode == id ? null : id;
    });
  }

  @override
  Widget build(BuildContext context) {
    final selected = selectedNode == null
        ? null
        : mapNodes.firstWhere((node) => node.id == selectedNode);

    return Scaffold(
      backgroundColor: AppTheme.bgPage,
      body: Column(
        children: [
          const MapHeader(),
          Expanded(
            child: SensorMapView(
              nodes: mapNodes,
              selectedNode: selectedNode,
              pingCtrl: pingCtrl,
              onNodeTap: toggleNode,
            ),
          ),
          if (selected != null) MapNodeDetail(node: selected),
          const MapLegend(),
          const SizedBox(height: 80),
        ],
      ),
    );
  }
}
