import 'package:flutter/material.dart';

import '../../theme/app_theme.dart';
import 'data/alert_data.dart';
import 'widgets/alert_app_bar.dart';
import 'widgets/alert_banner.dart';
import 'widgets/alert_card.dart';
import 'widgets/alert_filter.dart';
import 'widgets/report_section.dart';

class AlertScreen extends StatefulWidget {
  const AlertScreen({super.key});

  @override
  State<AlertScreen> createState() => _AlertScreenState();
}

class _AlertScreenState extends State<AlertScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController shake;
  String filter = 'Semua';

  @override
  void initState() {
    super.initState();
    shake = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    shake.dispose();
    super.dispose();
  }

  List<AlertData> get filteredAlerts {
    if (filter == 'Semua') return alertItems;

    final level = {
      'Kritis': 'critical',
      'Waspada': 'warning',
      'Info': 'info',
    }[filter];

    return alertItems.where((a) => a.level == level).toList();
  }

  @override
  Widget build(BuildContext context) {
    final unread = alertItems.where((a) => !a.read).length;

    return Scaffold(
      backgroundColor: AppTheme.bgPage,
      body: CustomScrollView(
        slivers: [
          AlertAppBar(unread: unread),
          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                AlertBanner(shake: shake),
                const SizedBox(height: 14),
                AlertFilter(
                  selected: filter,
                  onChanged: (v) => setState(() => filter = v),
                ),
                const SizedBox(height: 12),
                ...filteredAlerts.map((a) => AlertCard(alert: a)),
                const SizedBox(height: 14),
                const ReportSection(),
                const SizedBox(height: 100),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}
