import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';
import '../../../widgets/app_widgets.dart';

class ReportSection extends StatelessWidget {
  const ReportSection({super.key});

  @override
  Widget build(BuildContext context) {
    return const LightCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SectionHeader(
            title: 'Laporan Otomatis',
            subtitle: 'Pengiriman terjadwal',
          ),
          SizedBox(height: 12),
          _ReportRow(
            agency: 'DESDM Bangka Belitung',
            schedule: 'Harian 06:00',
            color: AppTheme.success,
            active: true,
          ),
          _ReportRow(
            agency: 'KLHK RI',
            schedule: 'Mingguan Senin',
            color: AppTheme.primary,
            active: true,
          ),
          _ReportRow(
            agency: 'Pemprov Babel',
            schedule: 'Bulanan',
            color: AppTheme.warning,
            active: false,
          ),
        ],
      ),
    );
  }
}

class _ReportRow extends StatelessWidget {
  final String agency;
  final String schedule;
  final Color color;
  final bool active;

  const _ReportRow({
    required this.agency,
    required this.schedule,
    required this.color,
    required this.active,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 9),
      child: Row(
        children: [
          Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: active ? color : AppTheme.textLight,
            ),
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              agency,
              style: const TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Text(
            schedule,
            style: const TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }
}
