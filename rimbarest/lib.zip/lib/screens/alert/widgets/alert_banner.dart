import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';

class AlertBanner extends StatelessWidget {
  final AnimationController shake;

  const AlertBanner({
    super.key,
    required this.shake,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.bgDanger,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.bdrDanger),
        boxShadow: [
          BoxShadow(
            color: AppTheme.danger.withValues(alpha: 0.08),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: shake,
            builder: (_, child) {
              return Transform.translate(
                offset: Offset(shake.value * 2 - 1, 0),
                child: child,
              );
            },
            child: const Icon(
              Icons.notification_important_rounded,
              color: AppTheme.danger,
              size: 30,
            ),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '2 Peringatan Kritis Aktif',
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                SizedBox(height: 3),
                Text(
                  'Memerlukan tindakan segera dari petugas lapangan',
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
