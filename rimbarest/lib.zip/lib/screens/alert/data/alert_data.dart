class AlertData {
  final String level;
  final String title;
  final String desc;
  final String time;
  final String node;
  final bool read;

  const AlertData({
    required this.level,
    required this.title,
    required this.desc,
    required this.time,
    required this.node,
    required this.read,
  });
}

const alertFilters = ['Semua', 'Kritis', 'Waspada', 'Info'];

const alertItems = [
  AlertData(
    level: 'critical',
    title: 'Deteksi Kebisingan Ekstrem',
    desc:
        'Node B1 Hutan Lindung — 78.2 dB. Kemungkinan aktivitas penambangan ilegal.',
    time: '09:38 WIB',
    node: 'B1 - Hutan Lindung',
    read: false,
  ),
  AlertData(
    level: 'warning',
    title: 'PM2.5 Melebihi Ambang Batas',
    desc: 'Konsentrasi PM2.5 di B1 mencapai 67.2 µg/m³, melewati ambang ISPU.',
    time: '09:12 WIB',
    node: 'B1 - Hutan Lindung',
    read: false,
  ),
  AlertData(
    level: 'info',
    title: 'Node D2 Offline',
    desc: 'Node D2 Hutan Lindung tidak mengirim data selama 2 jam.',
    time: '08:45 WIB',
    node: 'D2 - Hutan Lindung',
    read: true,
  ),
  AlertData(
    level: 'warning',
    title: 'Anomali Suara Fauna',
    desc: 'Penurunan aktivitas suara fauna. Indikasi gangguan ekosistem.',
    time: '07:30 WIB',
    node: 'A2 - Hutan Lindung',
    read: true,
  ),
  AlertData(
    level: 'info',
    title: 'Laporan Harian Dikirim',
    desc: 'Laporan otomatis dikirim ke DESDM dan KLHK.',
    time: '06:00 WIB',
    node: 'Sistem',
    read: true,
  ),
  AlertData(
    level: 'warning',
    title: 'Kualitas Udara Menurun',
    desc: 'Tren PM10 meningkat 23% dibanding kemarin di Belinyu.',
    time: 'Kemarin',
    node: 'B1 - Hutan Lindung',
    read: true,
  ),
];
