import 'package:flutter/material.dart';
import 'dart:async';

import '../../services/particulate_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_widgets.dart';

import 'data/particulate_data.dart';
import 'sensor_monitoring_screen.dart';
import 'widgets/particulate_app_bar.dart';
import 'widgets/particulate_aqi_scale.dart';
import 'widgets/particulate_gauge_card.dart';
import 'widgets/particulate_node_bars.dart';
import 'widgets/particulate_particle_sim.dart';
import 'widgets/particulate_trend_chart.dart';
import 'widgets/particulate_type_selector.dart';

class ParticulateScreen extends StatefulWidget {
  const ParticulateScreen({super.key});

  @override
  State<ParticulateScreen> createState() => _ParticulateScreenState();
}

class _ParticulateScreenState extends State<ParticulateScreen>
    with TickerProviderStateMixin {
  late final AnimationController gaugeCtrl;
  late final AnimationController particleCtrl;

  int selectedType = 1; // Default ke PM2.5 agar sesuai dengan gauge umum
  bool loading = true;
  String? errorMessage;
  Timer? _liveStreamTimer;

  Map<String, dynamic>? latestReading;
  Map<String, dynamic>? latestDetection;
  Map<String, dynamic>? latestNotification;

  @override
  void initState() {
    super.initState();

    gaugeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
      value: 0.0,
    );

    particleCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();

    loadLatest();

    _liveStreamTimer = Timer.periodic(const Duration(seconds: 4), (timer) {
      loadLatest(isSilent: true);
    });
  }

  @override
  void dispose() {
    _liveStreamTimer?.cancel();
    gaugeCtrl.dispose();
    particleCtrl.dispose();
    super.dispose();
  }

  Future<void> loadLatest({bool isSilent = false}) async {
    if (!isSilent) {
      setState(() {
        loading = true;
        errorMessage = null;
      });
    }

    try {
      final data = await ParticulateService.getLatest();

      final reading = data["latest_reading"];
      final detection = data["latest_detection"];
      final notification = data["latest_notification"];

      if (!mounted) return;

      setState(() {
        latestReading =
            reading == null ? null : Map<String, dynamic>.from(reading);
        latestDetection =
            detection == null ? null : Map<String, dynamic>.from(detection);
        latestNotification = notification == null
            ? null
            : Map<String, dynamic>.from(notification);
        loading = false;
        errorMessage = null;
      });

      final value = _getSelectedValue(reading);
      final maxScale = _getMaxScaleValue();
      final ratio = (value / maxScale).clamp(0.0, 1.0);

      gaugeCtrl.animateTo(
        ratio,
        duration: const Duration(milliseconds: 900),
        curve: Curves.easeOutCubic,
      );
    } catch (e) {
      if (!mounted) return;

      setState(() {
        loading = false;
        errorMessage = e.toString().replaceAll("Exception:", "").trim();
      });
    }
  }

  double _getSelectedValue(dynamic reading) {
    if (reading == null) return 0;

    switch (selectedType) {
      case 0:
        return _toDouble(reading["pm1"]);
      case 1:
        return _toDouble(reading["pm25"]);
      case 2:
        return _toDouble(reading["pm10"]);
      case 3:
        return _toDouble(reading["temperature"]);
      case 4:
        return _toDouble(reading["humidity"]);
      default:
        return 0;
    }
  }

  double _getMaxScaleValue() {
    // Menyesuaikan batas maksimum gauge berdasarkan tipe parameter
    if (selectedType == 3) return 50.0; // Max Suhu 50°C
    if (selectedType == 4) return 100.0; // Max Kelembapan 100%
    return 200.0; // Max PM
  }

  String _getUnitLabel() {
    if (selectedType == 3) return "°C";
    if (selectedType == 4) return "%";
    return "µg/m³";
  }

  double _toDouble(dynamic value) {
    if (value == null) return 0;
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString()) ?? 0;
  }

  String _statusLabel() {
    final risk = latestDetection?["risk_level"]?.toString().toUpperCase();
    if (risk == null || risk == "NORMAL") {
      return "NORMAL";
    }
    return risk;
  }

  Color _statusColor() {
    final risk = latestDetection?["risk_level"]?.toString().toLowerCase();

    if (risk == "kritis" || risk == "bahaya") {
      return AppTheme.danger;
    }
    if (risk == "waspada") {
      return AppTheme.warning;
    }
    return AppTheme.success;
  }

  @override
  Widget build(BuildContext context) {
    final value = _getSelectedValue(latestReading);
    final nodeName = latestReading?["node_name"]?.toString() ?? "NODE-001";
    final pm25 = _toDouble(latestReading?["pm25"]);
    final pm10 = _toDouble(latestReading?["pm10"]);
    final humidity = _toDouble(latestReading?["humidity"]);
    final temp = _toDouble(latestReading?["temperature"]);
    final confidence = _toDouble(latestDetection?["confidence"]);

    return Scaffold(
      backgroundColor: AppTheme.bgPage,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const SensorMonitoringScreen(),
            ),
          );
        },
        backgroundColor: AppTheme.primary,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.sensors_rounded),
        label: const Text("Live Monitor"),
      ),
      body: RefreshIndicator(
        onRefresh: loadLatest,
        child: CustomScrollView(
          slivers: [
            const ParticulateAppBar(),
            SliverPadding(
              padding: const EdgeInsets.all(16),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  ParticulateTypeSelector(
                    types: particulateTypes,
                    selectedIndex: selectedType,
                    onChanged: (i) {
                      setState(() => selectedType = i);

                      final nextValue = _getSelectedValue(latestReading);
                      final maxScale = _getMaxScaleValue();

                      gaugeCtrl.animateTo(
                        (nextValue / maxScale).clamp(0.0, 1.0),
                        duration: const Duration(milliseconds: 700),
                        curve: Curves.easeOutCubic,
                      );
                    },
                  ),
                  const SizedBox(height: 14),
                  if (loading)
                    const LightCard(
                      child: Padding(
                        padding: EdgeInsets.all(20),
                        child: Center(
                          child: CircularProgressIndicator(),
                        ),
                      ),
                    )
                  else if (errorMessage != null)
                    LightCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "Backend belum terhubung",
                            style: TextStyle(
                              fontWeight: FontWeight.w900,
                              color: AppTheme.danger,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            errorMessage!,
                            style: const TextStyle(
                              color: AppTheme.textSecondary,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    )
                  else if (latestReading == null)
                    const LightCard(
                      child: Text(
                        "Belum ada data Monitoring Partikulat di database.",
                        style: TextStyle(color: AppTheme.textSecondary),
                      ),
                    )
                  else ...[
                    ParticulateGaugeCard(
                      gaugeCtrl: gaugeCtrl,
                      value: value,
                      unit: _getUnitLabel(),
                      status: _statusLabel(),
                      statusColor: _statusColor(),
                      nodeName: nodeName,
                    ),
                    const SizedBox(height: 14),
                    if (latestNotification != null) ...[
                      _warningCard(latestNotification!),
                      const SizedBox(height: 14),
                    ],
                    InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                const SensorMonitoringScreen(),
                          ),
                        );
                      },
                      child: const LightCard(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Icon(Icons.analytics_outlined,
                                    color: AppTheme.primary),
                                SizedBox(width: 10),
                                Text(
                                  "Lihat Detail Real-Time Grafik",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            Icon(Icons.chevron_right_rounded,
                                color: AppTheme.textSecondary),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    _sensorDetailCard(
                      pm25: pm25,
                      pm10: pm10,
                      humidity: humidity,
                      temp: temp,
                      confidence: confidence,
                    ),
                  ],
                  const SizedBox(height: 14),
                  const SectionHeader(
                    title: 'Indeks Kualitas Udara',
                    subtitle: 'Berdasarkan ISPU Indonesia',
                  ),
                  const SizedBox(height: 10),
                  const ParticulateAqiScale(),
                  const SizedBox(height: 14),
                  const SectionHeader(
                    title: 'Data per Node',
                    subtitle: 'Perbandingan semua titik',
                  ),
                  const SizedBox(height: 10),
                  ParticulateNodeBars(
                    nodes: latestReading == null
                        ? nodeParticulateData
                        : [
                            NodeParticulateData(
                              name: nodeName,
                              value: value,
                            ),
                          ],
                  ),
                  const SizedBox(height: 14),
                  const SectionHeader(
                    title: 'Tren 7 Hari',
                    subtitle: 'Data historis',
                  ),
                  const SizedBox(height: 10),
                  const ParticulateTrendChart(),
                  const SizedBox(height: 14),
                  ParticulateParticleSim(particleCtrl: particleCtrl),
                  const SizedBox(height: 100),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _warningCard(Map<String, dynamic> notification) {
    return LightCard(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(
            Icons.warning_amber_rounded,
            color: AppTheme.danger,
            size: 28,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  notification["title"]?.toString() ?? "Peringatan Partikulat",
                  style: const TextStyle(
                    color: AppTheme.danger,
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  notification["message"]?.toString() ?? "-",
                  style: const TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _sensorDetailCard({
    required double pm25,
    required double pm10,
    required double humidity,
    required double temp,
    required double confidence,
  }) {
    return LightCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Detail Sensor dari Database",
            style: TextStyle(
              color: AppTheme.textPrimary,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 12),
          _row("PM2.5", "$pm25 µg/m³"),
          _row("PM10", "$pm10 µg/m³"),
          _row("Kelembapan", "$humidity%"),
          _row("Suhu", "$temp°C"),
          _row("Confidence AI", "$confidence%"),
        ],
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 7),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppTheme.textSecondary)),
          Text(
            value,
            style: const TextStyle(
              color: AppTheme.textPrimary,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}
