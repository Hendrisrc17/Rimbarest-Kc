import 'package:flutter/material.dart';

import '../data/particulate_data.dart';
import '../../../theme/app_theme.dart';

class ParticulateAqiScale extends StatelessWidget {
  const ParticulateAqiScale({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: aqiCategories.map((category) {
        return Expanded(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 2),
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              color: category.bg,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: category.border),
            ),
            child: Column(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: category.color,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  category.label,
                  style: TextStyle(
                    color: category.color,
                    fontSize: 8,
                    fontWeight: FontWeight.w700,
                  ),
                  textAlign: TextAlign.center,
                ),
                Text(
                  category.range,
                  style: const TextStyle(
                    color: AppTheme.textMuted,
                    fontSize: 7,
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}
