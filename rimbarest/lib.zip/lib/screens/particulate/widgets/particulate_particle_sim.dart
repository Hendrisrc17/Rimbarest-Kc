import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';
import 'particulate_painters.dart';

class ParticulateParticleSim extends StatelessWidget {
  final AnimationController particleCtrl;

  const ParticulateParticleSim({
    super.key,
    required this.particleCtrl,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.borderMedium),
        boxShadow: [
          BoxShadow(
            color: AppTheme.secondary.withValues(alpha: 0.06),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(
                Icons.science_rounded,
                color: AppTheme.secondary,
                size: 16,
              ),
              SizedBox(width: 7),
              Text(
                'Simulasi Dispersi Partikel',
                style: TextStyle(
                  color: AppTheme.secondary,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 110,
            child: AnimatedBuilder(
              animation: particleCtrl,
              builder: (_, __) {
                return CustomPaint(
                  size: const Size(double.infinity, 110),
                  painter: ParticlePainter(particleCtrl.value),
                );
              },
            ),
          ),
          const SizedBox(height: 7),
          const Text(
            'Model dispersi Gaussian · Angin: 3.2 m/s Barat Daya',
            style: TextStyle(
              color: AppTheme.textMuted,
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }
}
