import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';

class ParticulateAppBar extends StatelessWidget {
  const ParticulateAppBar({super.key});

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      pinned: true,
      backgroundColor: AppTheme.bgPage,
      surfaceTintColor: Colors.transparent,
      title: const Text('Deteksi Partikulat'),
      actions: [
        IconButton(
          icon: const Icon(
            Icons.download_rounded,
            color: AppTheme.textMuted,
          ),
          onPressed: () {},
        ),
      ],
    );
  }
}
