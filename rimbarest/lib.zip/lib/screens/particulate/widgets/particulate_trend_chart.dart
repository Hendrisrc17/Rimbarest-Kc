import 'package:flutter/material.dart';

import '../../../widgets/app_widgets.dart';
import 'particulate_painters.dart';

class ParticulateTrendChart extends StatelessWidget {
  const ParticulateTrendChart({super.key});

  @override
  Widget build(BuildContext context) {
    return LightCard(
      child: SizedBox(
        height: 120,
        child: CustomPaint(
          size: Size(
            MediaQuery.of(context).size.width - 64,
            120,
          ),
          painter: LineChartPainter(),
        ),
      ),
    );
  }
}
