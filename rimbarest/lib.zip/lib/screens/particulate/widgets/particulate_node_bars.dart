import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';
import '../../../widgets/app_widgets.dart';
import '../data/particulate_data.dart';

class ParticulateNodeBars extends StatelessWidget {
  final List<NodeParticulateData> nodes;

  const ParticulateNodeBars({
    super.key,
    required this.nodes,
  });

  @override
  Widget build(BuildContext context) {
    return LightCard(
      child: Column(
        children: nodes.map((node) {
          final ratio = (node.value / 200.0).clamp(0.0, 1.0);
          final color = ratio < 0.25
              ? AppTheme.success
              : ratio < 0.5
                  ? AppTheme.warning
                  : AppTheme.danger;

          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      node.name,
                      style: const TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      '${node.value.toStringAsFixed(1)} µg/m³',
                      style: TextStyle(
                        color: color,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: ratio,
                    backgroundColor: AppTheme.bgInput,
                    valueColor: AlwaysStoppedAnimation<Color>(color),
                    minHeight: 5,
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}
