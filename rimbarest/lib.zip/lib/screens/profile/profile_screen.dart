import 'package:flutter/material.dart';

import '../../auth/auth_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_widgets.dart';
import '../auth_gate_screen.dart';

import 'edit_profile_screen.dart';
import 'models/profile_state.dart';
import 'widgets/about_card.dart';
import 'widgets/interval_selector.dart';
import 'widgets/logout_button.dart';
import 'widgets/notifications_card.dart';
import 'widgets/profile_card.dart';
import 'widgets/profile_settings.dart';
import 'widgets/profile_stats.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool loading = true;

  Map<String, dynamic>? user;
  Map<String, dynamic>? summary;
  List<dynamic> notifList = [];

  ProfileState profileState = const ProfileState(
    notif: true,
    location: true,
    nightMode: false,
    interval: "5 detik",
  );

  @override
  void initState() {
    super.initState();
    loadAll();
  }

  Future<void> loadAll() async {
    try {
      final isLogin = await AuthService.isLoggedIn();

      if (!isLogin) {
        if (!mounted) return;
        setState(() {
          loading = false;
          user = null;
        });
        return;
      }

      final u = await AuthService.getProfile();
      final s = await AuthService.dashboardSummary();
      final n = await AuthService.notifications();

      final userData = Map<String, dynamic>.from(u["data"] ?? {});
      final summaryData = Map<String, dynamic>.from(s["data"] ?? {});
      final notificationData = List<dynamic>.from(n["data"] ?? []);

      if (!mounted) return;

      setState(() {
        user = userData;
        summary = summaryData;
        notifList = notificationData;
        profileState = ProfileState.fromUser(userData);
        loading = false;
      });
    } catch (_) {
      await AuthService.clearSession();

      if (!mounted) return;

      setState(() {
        loading = false;
        user = null;
      });

      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const AuthGateScreen()),
        (_) => false,
      );
    }
  }

  void showMsg(String msg) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> saveSetting({
    bool? notif,
    bool? location,
    bool? night,
    String? interval,
  }) async {
    final nextState = profileState.copyWith(
      notif: notif,
      location: location,
      nightMode: night,
      interval: interval,
    );

    setState(() => profileState = nextState);

    try {
      final result = await AuthService.updateProfile(
        notificationEnabled: nextState.notif,
        locationEnabled: nextState.location,
        nightMode: nextState.nightMode,
        syncInterval: nextState.interval,
      );

      final updated = Map<String, dynamic>.from(result["data"] ?? {});

      if (!mounted) return;

      setState(() {
        user = updated;
        profileState = ProfileState.fromUser(updated);
      });

      showMsg("Pengaturan disimpan");
    } catch (_) {
      await AuthService.clearSession();

      if (!mounted) return;

      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const AuthGateScreen()),
        (_) => false,
      );

      showMsg("Gagal menyimpan pengaturan");
    }
  }

  Future<void> pickPhoto() async {
    try {
      final updated = await ProfileCard.pickAndUploadPhoto();

      if (updated == null) return;
      if (!mounted) return;

      setState(() => user = Map<String, dynamic>.from(updated));

      showMsg("Foto profil berhasil diperbarui");
    } catch (_) {
      await AuthService.clearSession();

      if (!mounted) return;

      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const AuthGateScreen()),
        (_) => false,
      );

      showMsg("Gagal upload foto");
    }
  }

  Future<void> openEdit() async {
    if (user == null) return;

    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => EditProfileScreen(user: user!),
      ),
    );

    if (result == true) {
      await loadAll();
    }
  }

  Future<void> logout() async {
    await AuthService.logout();

    if (!mounted) return;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const AuthGateScreen()),
      (_) => false,
    );
  }

  Future<void> markNotificationRead(int id) async {
    try {
      await AuthService.markNotificationRead(id.toString());
      await loadAll();
    } catch (_) {
      await AuthService.clearSession();

      if (!mounted) return;

      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const AuthGateScreen()),
        (_) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        backgroundColor: AppTheme.bgPage,
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (user == null) {
      return const AuthGateScreen();
    }

    return Scaffold(
      backgroundColor: AppTheme.bgPage,
      body: RefreshIndicator(
        onRefresh: loadAll,
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              pinned: true,
              backgroundColor: AppTheme.bgPage,
              surfaceTintColor: Colors.transparent,
              title: const Text("Profil"),
              actions: [
                IconButton(
                  icon: const Icon(
                    Icons.edit_rounded,
                    color: AppTheme.textMuted,
                  ),
                  onPressed: openEdit,
                ),
              ],
            ),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  const SizedBox(height: 8),
                  ProfileCard(
                    user: user!,
                    onPhotoTap: pickPhoto,
                  ),
                  const SizedBox(height: 16),
                  ProfileStats(summary: summary),
                  const SizedBox(height: 16),
                  const SectionHeader(
                    title: "Pengaturan",
                    subtitle: "Konfigurasi aplikasi",
                  ),
                  const SizedBox(height: 10),
                  ProfileSettings(
                    notif: profileState.notif,
                    location: profileState.location,
                    nightMode: profileState.nightMode,
                    onNotifChanged: (v) => saveSetting(notif: v),
                    onLocationChanged: (v) => saveSetting(location: v),
                    onNightModeChanged: (v) => saveSetting(night: v),
                  ),
                  const SizedBox(height: 16),
                  const SectionHeader(
                    title: "Interval Sinkronisasi",
                    subtitle: "Frekuensi pembaruan data",
                  ),
                  const SizedBox(height: 10),
                  IntervalSelector(
                    current: profileState.interval,
                    onChanged: (v) => saveSetting(interval: v),
                  ),
                  const SizedBox(height: 16),
                  const SectionHeader(
                    title: "Notifikasi Terbaru",
                    subtitle: "Alert dari backend",
                  ),
                  const SizedBox(height: 10),
                  NotificationsCard(
                    notifEnabled: profileState.notif,
                    notifications: notifList,
                    onRead: markNotificationRead,
                  ),
                  const SizedBox(height: 16),
                  const SectionHeader(
                    title: "Tentang",
                    subtitle: "Informasi aplikasi",
                  ),
                  const SizedBox(height: 10),
                  const AboutCard(),
                  const SizedBox(height: 16),
                  LogoutButton(onTap: logout),
                  const SizedBox(height: 100),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
