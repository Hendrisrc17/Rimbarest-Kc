import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';

class ProfileStats extends StatelessWidget {
  final Map<String, dynamic>? summary;

  const ProfileStats({
    super.key,
    required this.summary,
  });

  @override
  Widget build(BuildContext context) {
    final stats = [
      {
        "label": "Node Aktif",
        "value": "${summary?["online_nodes"] ?? 0}",
        "color": AppTheme.primary,
        "border": AppTheme.bdrPrimary,
      },
      {
        "label": "Log",
        "value": "${summary?["total_detections"] ?? 0}",
        "color": AppTheme.secondary,
        "border": AppTheme.borderMedium,
      },
      {
        "label": "Alert",
        "value": "${summary?["total_alerts"] ?? 0}",
        "color": AppTheme.danger,
        "border": AppTheme.bdrDanger,
      },
      {
        "label": "Notif",
        "value": "${summary?["unread_notifications"] ?? 0}",
        "color": AppTheme.success,
        "border": AppTheme.bdrSuccess,
      },
    ];

    return Row(
      children: stats.map((s) {
        final color = s["color"] as Color;
        final border = s["border"] as Color;

        return Expanded(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 3),
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: border),
              boxShadow: [
                BoxShadow(
                  color: color.withValues(alpha: 0.05),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              children: [
                Text(
                  s["value"] as String,
                  style: TextStyle(
                    color: color,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  s["label"] as String,
                  style: const TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 8,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}
