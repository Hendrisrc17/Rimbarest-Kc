import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';
import '../../../widgets/app_widgets.dart';

class NotificationsCard extends StatelessWidget {
  final bool notifEnabled;
  final List<dynamic> notifications;
  final Future<void> Function(int id) onRead;

  const NotificationsCard({
    super.key,
    required this.notifEnabled,
    required this.notifications,
    required this.onRead,
  });

  @override
  Widget build(BuildContext context) {
    if (!notifEnabled) {
      return const LightCard(
        child: Text(
          "Notifikasi sedang nonaktif.",
          style: TextStyle(color: AppTheme.textSecondary),
        ),
      );
    }

    if (notifications.isEmpty) {
      return const LightCard(
        child: Text(
          "Belum ada notifikasi.",
          style: TextStyle(color: AppTheme.textSecondary),
        ),
      );
    }

    return LightCard(
      padding: EdgeInsets.zero,
      child: Column(
        children: notifications.take(5).map((n) {
          final isUnread = n["status"] == "belum_dibaca";
          final id = n["id"];

          return Column(
            children: [
              ListTile(
                leading: Icon(
                  isUnread
                      ? Icons.notifications_active_rounded
                      : Icons.notifications_none_rounded,
                  color: isUnread ? AppTheme.danger : AppTheme.textMuted,
                ),
                title: Text(
                  n["title"] ?? "-",
                  style: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
                subtitle: Text(
                  n["message"] ?? "-",
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 11,
                  ),
                ),
                trailing: isUnread
                    ? TextButton(
                        onPressed: id == null
                            ? null
                            : () => onRead(int.parse(id.toString())),
                        child: const Text("Baca"),
                      )
                    : const Icon(
                        Icons.check_circle,
                        color: AppTheme.success,
                        size: 18,
                      ),
              ),
              _divider(),
            ],
          );
        }).toList(),
      ),
    );
  }

  Widget _divider() {
    return Container(
      height: 1,
      margin: const EdgeInsets.symmetric(horizontal: 14),
      color: AppTheme.borderSoft,
    );
  }
}
