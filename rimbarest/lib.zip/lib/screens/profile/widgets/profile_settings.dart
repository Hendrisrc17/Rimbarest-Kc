import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';
import '../../../widgets/app_widgets.dart';

class ProfileSettings extends StatelessWidget {
  final bool notif;
  final bool location;
  final bool nightMode;

  final ValueChanged<bool> onNotifChanged;
  final ValueChanged<bool> onLocationChanged;
  final ValueChanged<bool> onNightModeChanged;

  const ProfileSettings({
    super.key,
    required this.notif,
    required this.location,
    required this.nightMode,
    required this.onNotifChanged,
    required this.onLocationChanged,
    required this.onNightModeChanged,
  });

  @override
  Widget build(BuildContext context) {
    return LightCard(
      padding: EdgeInsets.zero,
      child: Column(
        children: [
          _toggleRow(
            "Notifikasi Push",
            Icons.notifications_rounded,
            notif,
            onNotifChanged,
          ),
          _divider(),
          _toggleRow(
            "Lokasi Real-time",
            Icons.location_on_rounded,
            location,
            onLocationChanged,
          ),
          _divider(),
          _toggleRow(
            "Mode Malam",
            Icons.nightlight_round,
            nightMode,
            onNightModeChanged,
          ),
          _divider(),
          _arrowRow("Bahasa", Icons.language_rounded, "Indonesia"),
          _divider(),
          _arrowRow(
            "Tema Warna",
            Icons.palette_rounded,
            nightMode ? "Mode Malam" : "Mode Terang",
          ),
        ],
      ),
    );
  }

  Widget _toggleRow(
    String label,
    IconData icon,
    bool value,
    ValueChanged<bool> onChanged,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: AppTheme.bgPrimary,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: AppTheme.primary, size: 16),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Switch(
            value: value,
            activeThumbColor: AppTheme.primary,
            activeTrackColor: AppTheme.primary.withValues(alpha: 0.35),
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  Widget _arrowRow(String label, IconData icon, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: AppTheme.bgPrimary,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: AppTheme.primary, size: 16),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 12,
            ),
          ),
          const SizedBox(width: 4),
          const Icon(
            Icons.chevron_right,
            color: AppTheme.textLight,
            size: 16,
          ),
        ],
      ),
    );
  }

  Widget _divider() {
    return Container(
      height: 1,
      margin: const EdgeInsets.symmetric(horizontal: 14),
      color: AppTheme.borderSoft,
    );
  }
}
