import 'package:flutter/material.dart';

import '../../theme/app_theme.dart';
import '../../widgets/app_widgets.dart';
import 'data/audio_data.dart';
import 'widgets/audio_app_bar.dart';
import 'widgets/audio_category_filter.dart';
import 'widgets/audio_event_list.dart';
import 'widgets/audio_spectrum.dart';
import 'widgets/audio_wave_box.dart';
import 'widgets/node_tabs.dart';

class AudioScreen extends StatefulWidget {
  const AudioScreen({super.key});

  @override
  State<AudioScreen> createState() => _AudioScreenState();
}

class _AudioScreenState extends State<AudioScreen>
    with TickerProviderStateMixin {
  late final AnimationController waveCtrl;
  late final AnimationController pulseCtrl;

  int selectedNode = 0;
  String selectedCat = 'Semua';

  @override
  void initState() {
    super.initState();

    waveCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..repeat();

    pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    waveCtrl.dispose();
    pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgPage,
      body: CustomScrollView(
        slivers: [
          const AudioAppBar(),
          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                AudioWaveBox(
                  waveCtrl: waveCtrl,
                  pulseCtrl: pulseCtrl,
                ),
                const SizedBox(height: 14),
                NodeTabs(
                  selectedIndex: selectedNode,
                  onChanged: (i) => setState(() => selectedNode = i),
                ),
                const SizedBox(height: 14),
                const SectionHeader(
                  title: 'Klasifikasi Suara AI',
                  subtitle: 'Deteksi real-time',
                ),
                const SizedBox(height: 8),
                AudioCategoryFilter(
                  selected: selectedCat,
                  onChanged: (v) => setState(() => selectedCat = v),
                ),
                const SizedBox(height: 8),
                AudioEventList(
                  events: filteredAudioEvents(selectedCat),
                ),
                const SizedBox(height: 14),
                AudioSpectrum(waveCtrl: waveCtrl),
                const SizedBox(height: 100),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}
