import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';
import 'audio_painters.dart';

class AudioWaveBox extends StatelessWidget {
  final AnimationController waveCtrl;
  final AnimationController pulseCtrl;

  const AudioWaveBox({
    super.key,
    required this.waveCtrl,
    required this.pulseCtrl,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 140,
      decoration: BoxDecoration(
        color: AppTheme.bgSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderMedium),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primary.withValues(alpha: 0.06),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Stack(
        children: [
          _WaveCanvas(waveCtrl: waveCtrl),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _LiveHeader(pulseCtrl: pulseCtrl),
                const Spacer(),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _DbBadge(
                      value: '62.4 dB',
                      label: 'Saat Ini',
                      color: AppTheme.primary,
                    ),
                    _DbBadge(
                      value: '78.1 dB',
                      label: 'Puncak',
                      color: AppTheme.danger,
                    ),
                    _DbBadge(
                      value: '44.2 dB',
                      label: 'Min',
                      color: AppTheme.success,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _WaveCanvas extends StatelessWidget {
  final AnimationController waveCtrl;

  const _WaveCanvas({required this.waveCtrl});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: AnimatedBuilder(
        animation: waveCtrl,
        builder: (_, __) {
          return CustomPaint(
            size: Size(
              MediaQuery.of(context).size.width - 32,
              140,
            ),
            painter: WavePainter(waveCtrl.value),
          );
        },
      ),
    );
  }
}

class _LiveHeader extends StatelessWidget {
  final AnimationController pulseCtrl;

  const _LiveHeader({required this.pulseCtrl});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        AnimatedBuilder(
          animation: pulseCtrl,
          builder: (_, __) {
            return Container(
              width: 7,
              height: 7,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppTheme.danger,
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.danger.withValues(
                      alpha: 0.5 * pulseCtrl.value,
                    ),
                    blurRadius: 6,
                  ),
                ],
              ),
            );
          },
        ),
        const SizedBox(width: 7),
        const Text(
          'REKAM LIVE',
          style: TextStyle(
            color: AppTheme.danger,
            fontSize: 10,
            fontWeight: FontWeight.w800,
            letterSpacing: 2,
          ),
        ),
        const Spacer(),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.8),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: AppTheme.borderSoft),
          ),
          child: const Text(
            '00:04:32',
            style: TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 11,
              fontFamily: 'monospace',
            ),
          ),
        ),
      ],
    );
  }
}

class _DbBadge extends StatelessWidget {
  final String value;
  final String label;
  final Color color;

  const _DbBadge({
    required this.value,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 15,
            fontWeight: FontWeight.w900,
          ),
        ),
        Text(
          label,
          style: const TextStyle(
            color: AppTheme.textMuted,
            fontSize: 10,
          ),
        ),
      ],
    );
  }
}
