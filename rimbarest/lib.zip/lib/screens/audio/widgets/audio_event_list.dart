import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';
import '../data/audio_data.dart';

class AudioEventList extends StatelessWidget {
  final List<AudioEventData> events;

  const AudioEventList({
    super.key,
    required this.events,
  });

  @override
  Widget build(BuildContext context) {
    if (events.isEmpty) {
      return const _EmptyAudioEvent();
    }

    return Column(
      children: events.map((event) {
        return _AudioEventCard(event: event);
      }).toList(),
    );
  }
}

class _AudioEventCard extends StatelessWidget {
  final AudioEventData event;

  const _AudioEventCard({required this.event});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 7),
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: event.border),
        boxShadow: [
          BoxShadow(
            color: event.color.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: event.bg,
              borderRadius: BorderRadius.circular(9),
            ),
            child: Center(
              child: Text(
                event.icon,
                style: const TextStyle(fontSize: 17),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  event.type,
                  style: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '${event.time} · ${event.duration} · Conf: ${event.confidence}',
                  style: const TextStyle(
                    color: AppTheme.textMuted,
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
          Text(
            '${event.db} dB',
            style: TextStyle(
              color: event.color,
              fontSize: 13,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyAudioEvent extends StatelessWidget {
  const _EmptyAudioEvent();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.borderSoft),
      ),
      child: const Text(
        'Belum ada event audio pada kategori ini.',
        style: TextStyle(
          color: AppTheme.textSecondary,
          fontSize: 12,
        ),
      ),
    );
  }
}
