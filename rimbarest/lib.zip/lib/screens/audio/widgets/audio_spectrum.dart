import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';
import '../../../widgets/app_widgets.dart';
import 'audio_painters.dart';

class AudioSpectrum extends StatelessWidget {
  final AnimationController waveCtrl;

  const AudioSpectrum({
    super.key,
    required this.waveCtrl,
  });

  @override
  Widget build(BuildContext context) {
    return LightCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Spektrum Frekuensi',
            style: TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 2),
          const Text(
            'FFT Real-time · 44.1 kHz',
            style: TextStyle(
              color: AppTheme.textMuted,
              fontSize: 10,
            ),
          ),
          const SizedBox(height: 12),
          AnimatedBuilder(
            animation: waveCtrl,
            builder: (_, __) {
              return CustomPaint(
                size: Size(
                  MediaQuery.of(context).size.width - 64,
                  80,
                ),
                painter: SpectrumPainter(waveCtrl.value),
              );
            },
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: audioFrequencies.map((f) {
              return Text(
                f,
                style: const TextStyle(
                  color: AppTheme.textLight,
                  fontSize: 8,
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

const audioFrequencies = [
  '20Hz',
  '100Hz',
  '1kHz',
  '10kHz',
  '20kHz',
];
