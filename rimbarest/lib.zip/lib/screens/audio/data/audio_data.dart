import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';

class AudioEventData {
  final String type;
  final String db;
  final String time;
  final String duration;
  final String confidence;
  final String icon;
  final Color color;
  final Color bg;
  final Color border;

  const AudioEventData({
    required this.type,
    required this.db,
    required this.time,
    required this.duration,
    required this.confidence,
    required this.icon,
    required this.color,
    required this.bg,
    required this.border,
  });
}

const audioNodes = [
  'A1 Hutan Lindung',
];

const audioCategories = [
  'Semua',
  'Penambangan',
  'CainSaw',
  'Fauna',
  'Angin',
];

const audioEvents = [
  AudioEventData(
    type: 'Penambangan',
    db: '78.2',
    time: '09:38',
    duration: '4m 21s',
    confidence: '94%',
    icon: '⛏️',
    color: AppTheme.danger,
    bg: AppTheme.bgDanger,
    border: AppTheme.bdrDanger,
  ),
  AudioEventData(
    type: 'CainSaw',
    db: '71.5',
    time: '09:21',
    duration: '1m 08s',
    confidence: '88%',
    icon: '🪚',
    color: AppTheme.warning,
    bg: AppTheme.bgWarning,
    border: AppTheme.bdrWarning,
  ),
  AudioEventData(
    type: 'Fauna - Burung',
    db: '52.1',
    time: '09:10',
    duration: '0m 45s',
    confidence: '96%',
    icon: '🐦',
    color: AppTheme.success,
    bg: AppTheme.bgSuccess,
    border: AppTheme.bdrSuccess,
  ),
  AudioEventData(
    type: 'Angin',
    db: '44.3',
    time: '08:54',
    duration: '12m',
    confidence: '99%',
    icon: '🌀',
    color: AppTheme.secondary,
    bg: AppTheme.bgSecondary,
    border: AppTheme.borderMedium,
  ),
];

List<AudioEventData> filteredAudioEvents(String category) {
  if (category == 'Semua') return audioEvents;

  return audioEvents.where((e) {
    return e.type.toLowerCase().contains(category.toLowerCase());
  }).toList();
}
