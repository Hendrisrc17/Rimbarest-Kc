import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';

class DashboardStatData {
  final String label;
  final String value;
  final String unit;
  final IconData icon;
  final String status;
  final Color accentColor;
  final Color bgColor;
  final Color borderColor;
  final String trend;
  final bool trendUp;

  const DashboardStatData({
    required this.label,
    required this.value,
    required this.unit,
    required this.icon,
    required this.status,
    required this.accentColor,
    required this.bgColor,
    required this.borderColor,
    required this.trend,
    required this.trendUp,
  });
}

class NodeData {
  final String name;
  final String status;
  final String pm;
  final String db;

  const NodeData({
    required this.name,
    required this.status,
    required this.pm,
    required this.db,
  });
}

const List<DashboardStatData> dashboardStats = [
  DashboardStatData(
    label: 'PM2.5',
    value: '24.7',
    unit: 'µg/m³',
    icon: Icons.grain_rounded,
    status: 'Sedang',
    accentColor: AppTheme.danger,
    bgColor: AppTheme.bgDanger,
    borderColor: AppTheme.bdrDanger,
    trend: '+2.1',
    trendUp: true,
  ),
  DashboardStatData(
    label: 'PM10',
    value: '48.3',
    unit: 'µg/m³',
    icon: Icons.scatter_plot_rounded,
    status: 'Baik',
    accentColor: AppTheme.success,
    bgColor: AppTheme.bgSuccess,
    borderColor: AppTheme.bdrSuccess,
    trend: '-1.5',
    trendUp: false,
  ),
  DashboardStatData(
    label: 'Kebisingan',
    value: '62.4',
    unit: 'dB',
    icon: Icons.graphic_eq_rounded,
    status: 'Normal',
    accentColor: AppTheme.secondary,
    bgColor: AppTheme.bgSecondary,
    borderColor: AppTheme.borderMedium,
    trend: '+0.8',
    trendUp: true,
  ),
  DashboardStatData(
    label: 'Temperature',
    value: '28.6',
    unit: '°C',
    icon: Icons.thermostat_rounded,
    status: 'Normal',
    accentColor: AppTheme.warning,
    bgColor: AppTheme.bgWarning,
    borderColor: AppTheme.bdrWarning,
    trend: '+0.5',
    trendUp: true,
  ),
];

const List<NodeData> dashboardNodes = [
  NodeData(
    name: 'Node A1 - Hutan Lindung',
    status: 'online',
    pm: '22.1',
    db: '58',
  ),
];
