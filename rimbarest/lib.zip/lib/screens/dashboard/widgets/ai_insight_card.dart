import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';

class AiInsightCard extends StatelessWidget {
  const AiInsightCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.borderMedium),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primary.withValues(alpha: 0.08),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _AiHeader(),
          SizedBox(height: 10),
          Text(
            'Deteksi pola suara tidak biasa di Node B1 Belinyu. '
            'Kemungkinan aktivitas penambangan ilegal pada koordinat '
            '(-1.9234, 105.7819). Tingkat keyakinan: 87.3%',
            style: TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 12,
              height: 1.5,
            ),
          ),
          SizedBox(height: 10),
          Wrap(
            spacing: 7,
            children: [
              _Chip(
                label: '🔊 Audio Anomali',
                color: AppTheme.primary,
                bg: AppTheme.bgPrimary,
                border: AppTheme.bdrPrimary,
              ),
              _Chip(
                label: '⚠️ PM2.5 Tinggi',
                color: AppTheme.danger,
                bg: AppTheme.bgDanger,
                border: AppTheme.bdrDanger,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _AiHeader extends StatelessWidget {
  const _AiHeader();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            color: AppTheme.bgPrimary,
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Icon(
            Icons.auto_awesome,
            color: AppTheme.primary,
            size: 15,
          ),
        ),
        const SizedBox(width: 9),
        const Text(
          'AI Edge Insight',
          style: TextStyle(
            color: AppTheme.primary,
            fontSize: 13,
            fontWeight: FontWeight.w800,
          ),
        ),
        const Spacer(),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
          decoration: BoxDecoration(
            color: AppTheme.bgPrimary,
            borderRadius: BorderRadius.circular(6),
          ),
          child: const Text(
            'TFLite',
            style: TextStyle(
              fontSize: 8,
              color: AppTheme.primary,
            ),
          ),
        ),
      ],
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  final Color color;
  final Color bg;
  final Color border;

  const _Chip({
    required this.label,
    required this.color,
    required this.bg,
    required this.border,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: border),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
