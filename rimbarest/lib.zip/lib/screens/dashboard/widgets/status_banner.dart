import 'package:flutter/material.dart';

import '../../../theme/app_theme.dart';

class StatusBanner extends StatelessWidget {
  const StatusBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LightGradients.statusGrad,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.borderMedium),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primary.withValues(alpha: 0.06),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: const Row(
        children: [
          Expanded(child: _StatusInfo()),
          _NodeCounter(),
        ],
      ),
    );
  }
}

class _StatusInfo extends StatelessWidget {
  const _StatusInfo();

  @override
  Widget build(BuildContext context) {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              Icons.check_circle_rounded,
              color: AppTheme.success,
              size: 14,
            ),
            SizedBox(width: 5),
            Text(
              'Sistem Beroperasi Normal',
              style: TextStyle(
                color: AppTheme.success,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        SizedBox(height: 3),
        Text(
          'Senin, 18 Mar 2026 · 09:42 WIB',
          style: TextStyle(
            color: AppTheme.textMuted,
            fontSize: 10,
          ),
        ),
      ],
    );
  }
}

class _NodeCounter extends StatelessWidget {
  const _NodeCounter();

  @override
  Widget build(BuildContext context) {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          '8/8',
          style: TextStyle(
            color: AppTheme.primary,
            fontSize: 22,
            fontWeight: FontWeight.w900,
          ),
        ),
        Text(
          'Node Online',
          style: TextStyle(
            color: AppTheme.textMuted,
            fontSize: 9,
          ),
        ),
      ],
    );
  }
}
