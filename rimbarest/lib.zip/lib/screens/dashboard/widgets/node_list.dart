import 'package:flutter/material.dart';

import '../../../widgets/app_widgets.dart';
import '../data/dashboard_data.dart';

class NodeList extends StatelessWidget {
  const NodeList({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: dashboardNodes.map((n) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: NodeRow(
            name: n.name,
            status: n.status,
            pm: n.pm,
            db: n.db,
          ),
        );
      }).toList(),
    );
  }
}
