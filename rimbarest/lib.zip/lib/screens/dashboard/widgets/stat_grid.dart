import 'package:flutter/material.dart';

import '../../../widgets/app_widgets.dart';
import '../data/dashboard_data.dart';

class StatGrid extends StatelessWidget {
  const StatGrid({super.key});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      padding: EdgeInsets.zero,
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      childAspectRatio: 1.5,
      children: dashboardStats.map((s) {
        return StatCard(
          label: s.label,
          value: s.value,
          unit: s.unit,
          icon: s.icon,
          status: s.status,
          accentColor: s.accentColor,
          bgColor: s.bgColor,
          borderColor: s.borderColor,
          trend: s.trend,
          trendUp: s.trendUp,
        );
      }).toList(),
    );
  }
}
