import 'package:flutter/material.dart';

import '../../theme/app_theme.dart';
import '../../widgets/app_widgets.dart';
import 'widgets/ai_insight_card.dart';
import 'widgets/dashboard_app_bar.dart';
import 'widgets/node_list.dart';
import 'widgets/stat_grid.dart';
import 'widgets/status_banner.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController pulse;

  @override
  void initState() {
    super.initState();
    pulse = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgPage,
      body: CustomScrollView(
        slivers: [
          DashboardAppBar(pulse: pulse),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverList(
              delegate: SliverChildListDelegate(
                const [
                  SizedBox(height: 8),
                  StatusBanner(),
                  SizedBox(height: 12),
                  SectionHeader(
                    title: 'Status Real-time',
                    subtitle: 'Semua node aktif',
                  ),
                  SizedBox(height: 4),
                  StatGrid(),
                  SizedBox(height: 12),
                  SectionHeader(
                    title: 'Node Sensor',
                    subtitle: '8 titik pemantauan',
                  ),
                  SizedBox(height: 6),
                  NodeList(),
                  SizedBox(height: 12),
                  SectionHeader(
                    title: 'Tren 24 Jam',
                    subtitle: 'Rata-rata sistem',
                  ),
                  SizedBox(height: 6),
                  LightCard(
                    child: SizedBox(
                      height: 160,
                      child: TrendChart(),
                    ),
                  ),
                  SizedBox(height: 12),
                  AiInsightCard(),
                  SizedBox(height: 80),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
