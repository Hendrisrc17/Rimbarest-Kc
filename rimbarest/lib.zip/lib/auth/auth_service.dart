import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'api_config.dart';

class AuthService {
  static const String _tokenKey = "token";
  static const String _userKey = "user";

  // Helper untuk melampirkan token otentikasi di setiap request
  static Future<Map<String, String>> _headers() async {
    final token = await getToken();

    return {
      "Content-Type": "application/json",
      "Accept": "application/json",
      if (token != null && token.isNotEmpty) "Authorization": "Bearer $token",
    };
  }

  // Helper penanganan response HTTP
  static dynamic _handle(http.Response response) {
    final data = jsonDecode(response.body);

    if (response.statusCode >= 200 && response.statusCode < 300) {
      return data;
    }

    throw Exception(data["message"] ?? "Request gagal");
  }

  // ==========================================
  // FITUR: AUTHENTICATION & SESSION
  // ==========================================

  // 1. REGISTER -> Mengarah ke api/mobile/login-register/register[cite: 1]
  static Future<Map<String, dynamic>> register({
    required String firstName,
    required String username,
    required String email,
    required String phone,
    required String password,
  }) async {
    final response = await http.post(
      Uri.parse("${ApiConfig.baseUrl}/mobile/login-register/register"),
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: jsonEncode({
        "firstName": firstName,
        "username": username,
        "email": email,
        "phone": phone,
        "password": password,
      }),
    );

    final data = _handle(response);

    if (data["data"]?["token"] != null) {
      await saveSession(data["data"]["token"], data["data"]["user"]);
    }

    return Map<String, dynamic>.from(data);
  }

  // 2. LOGIN -> Mengarah ke api/mobile/login-register/login[cite: 1]
  static Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) async {
    final response = await http.post(
      Uri.parse("${ApiConfig.baseUrl}/mobile/login-register/login"),
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: jsonEncode({
        "usernameOrEmail": email,
        "password": password,
      }),
    );

    final data = _handle(response);

    if (data["data"]?["token"] != null) {
      await saveSession(data["data"]["token"], data["data"]["user"]);
    }

    return Map<String, dynamic>.from(data);
  }

  // 3. GET SESSION USER -> Mengarah ke api/mobile/login-register/me[cite: 1]
  static Future<Map<String, dynamic>> getProfile() async {
    final response = await http.get(
      Uri.parse("${ApiConfig.baseUrl}/mobile/login-register/me"),
      headers: await _headers(),
    );

    final data = _handle(response);

    if (data["data"] != null) {
      final token = await getToken();
      if (token != null) {
        await saveSession(token, data["data"]);
      }
    }

    return Map<String, dynamic>.from(data);
  }

  // Manajemen Session Lokal via SharedPreferences
  static Future<void> saveSession(String token, dynamic user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, token);
    await prefs.setString(_userKey, jsonEncode(user));
  }

  static Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    await prefs.remove(_userKey);
  }

  static Future<void> logout() async {
    await clearSession();
  }

  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_tokenKey);
  }

  static Future<Map<String, dynamic>?> getUser() async {
    final prefs = await SharedPreferences.getInstance();
    final userString = prefs.getString(_userKey);

    if (userString == null) return null;

    return Map<String, dynamic>.from(jsonDecode(userString));
  }

  static Future<bool> isLoggedIn() async {
    final token = await getToken();
    return token != null && token.isNotEmpty;
  }

  // ==========================================
  // FITUR: USER PROFILE MANAGEMENT
  // ==========================================

  // UPDATE PROFILE TOKEN -> Mengarah ke api/mobile/profile/token[cite: 1]
  static Future<Map<String, dynamic>> updateProfile({
    String? firstName,
    String? lastName,
    String? phone,
    String? address,
    bool? locationEnabled,
    bool? nightMode,
    bool? notificationEnabled,
    String? syncInterval,
  }) async {
    final response = await http.put(
      Uri.parse("${ApiConfig.baseUrl}/mobile/profile/token"),
      headers: await _headers(),
      body: jsonEncode({
        "firstName": firstName,
        "lastName": lastName,
        "phone": phone,
        "address": address,
        "locationEnabled": locationEnabled,
        "nightMode": nightMode,
        "notificationEnabled": notificationEnabled,
        "syncInterval": syncInterval,
      }),
    );

    return Map<String, dynamic>.from(_handle(response));
  }

  // ==========================================
  // FITUR: MONITORING & DASHBOARD DATA
  // ==========================================

  // GET DASHBOARD SUMMARY -> Mengarah ke api/mobile/dashboard[cite: 1]
  static Future<Map<String, dynamic>> dashboardSummary() async {
    final response = await http.get(
      Uri.parse("${ApiConfig.baseUrl}/mobile/dashboard"),
      headers: await _headers(),
    );

    return Map<String, dynamic>.from(_handle(response));
  }

  // GET LIVE AUDIO -> Mengarah ke api/mobile/live-monitoring-frekuensi-audio[cite: 1]
  static Future<Map<String, dynamic>> getLiveAudioMonitoring() async {
    final response = await http.get(
      Uri.parse("${ApiConfig.baseUrl}/mobile/live-monitoring-frekuensi-audio"),
      headers: await _headers(),
    );

    return Map<String, dynamic>.from(_handle(response));
  }

  // GET LIVE PARTICULATE -> Mengarah ke api/mobile/live-monitoring-partikulat[cite: 1]
  static Future<Map<String, dynamic>> getLiveParticulateMonitoring() async {
    final response = await http.get(
      Uri.parse("${ApiConfig.baseUrl}/mobile/live-monitoring-partikulat"),
      headers: await _headers(),
    );

    return Map<String, dynamic>.from(_handle(response));
  }

  // GET ALL NODES -> Mengarah ke api/mobile/node[cite: 1]
  static Future<Map<String, dynamic>> getNodes() async {
    final response = await http.get(
      Uri.parse("${ApiConfig.baseUrl}/mobile/node"),
      headers: await _headers(),
    );

    return Map<String, dynamic>.from(_handle(response));
  }

  // GET SPECIFIC NODE -> Mengarah ke api/mobile/node/[nodeCode][cite: 1]
  static Future<Map<String, dynamic>> getNodeDetail(String nodeCode) async {
    final response = await http.get(
      Uri.parse("${ApiConfig.baseUrl}/mobile/node/$nodeCode"),
      headers: await _headers(),
    );

    return Map<String, dynamic>.from(_handle(response));
  }

  // GET AI AUDIO PREDICTION -> Mengarah ke api/mobile/prediksi-ai-audio[cite: 1]
  static Future<Map<String, dynamic>> getAiAudioPrediction() async {
    final response = await http.get(
      Uri.parse("${ApiConfig.baseUrl}/mobile/prediksi-ai-audio"),
      headers: await _headers(),
    );

    return Map<String, dynamic>.from(_handle(response));
  }

  // ==========================================
  // FITUR: NOTIFICATION MANAGEMENT
  // ==========================================

  // GET NOTIFICATIONS -> Mengarah ke api/mobile/notifikasi[cite: 1]
  static Future<Map<String, dynamic>> notifications() async {
    final response = await http.get(
      Uri.parse("${ApiConfig.baseUrl}/mobile/notifikasi"),
      headers: await _headers(),
    );

    return Map<String, dynamic>.from(_handle(response));
  }

  // UPDATE STATUS NOTIFIKASI -> Mengarah ke api/mobile/notifikasi[cite: 1]
  static Future<Map<String, dynamic>> markNotificationRead(String id) async {
    final response = await http.put(
      Uri.parse("${ApiConfig.baseUrl}/mobile/notifikasi"),
      headers: await _headers(),
      body: jsonEncode({
        "id": id,
        "status": "DIBACA",
      }),
    );

    return Map<String, dynamic>.from(_handle(response));
  }
}
