class ApiConfig {
  // Ganti sesuai dengan IP backend Anda saat development
  static const String baseUrl = 'http://10.0.2.2:3000/api/mobile';
}
